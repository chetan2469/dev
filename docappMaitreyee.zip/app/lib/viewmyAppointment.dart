import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';

class ViewmyAppointment extends StatefulWidget {
  GoogleSignInAccount user;

  ViewmyAppointment(this.user);

  @override
  _ViewmyAppointmentState createState() => _ViewmyAppointmentState();
}

class _ViewmyAppointmentState extends State<ViewmyAppointment> {
  Map daySheduleMap = {};
  List<Map> list = [];
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  Timestamp dayOfAppointment = Timestamp.fromMillisecondsSinceEpoch(34567890);
  String appointmentTime = '';
  Timestamp bookingTime = Timestamp.fromMillisecondsSinceEpoch(34567890);
  String bookingId = '', problem = '';
  List<String> months = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December'
  ];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    readMyAppointment();
  }

  void readMyAppointment() async {
    DocumentSnapshot documentSnapshot;
    try {
      documentSnapshot = await firestore
          .collection('docusers')
          .doc(widget.user.email.toString())
          .get();
      print((documentSnapshot.data() as dynamic)['booking']);
      setState(() {
        bookingId = (documentSnapshot.data() as dynamic)['booking'];
      });
      documentSnapshot =
          await firestore.collection('doctorAppointments').doc(bookingId).get();

      setState(() {
        problem = (documentSnapshot.data() as dynamic)['diseases'];
        dayOfAppointment =
            (documentSnapshot.data() as dynamic)['appointmentDay'];
        appointmentTime =
            (documentSnapshot.data() as dynamic)['appointmentTime'];
        bookingTime = (documentSnapshot.data() as dynamic)['bookingTime'];
      });
    } catch (e) {
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Column(children: [
            Row(
              children: [
                Container(
                  margin: EdgeInsets.only(top: 18, left: 5),
                  alignment: Alignment.topLeft,
                  child: IconButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      icon: Icon(Icons.arrow_back, size: 35)),
                ),
                Container(
                  margin: EdgeInsets.only(top: 18, left: 65),
                  child: Text(
                    'Your Appointment',
                    style: TextStyle(fontSize: 20),
                  ),
                ),
              ],
            ),

            //   Container(
            //     margin: EdgeInsets.only(top: 18, left: 0, right: 18),
            //     child: Text('Hello ' + widget.user.displayName.toString() + '!',
            //         style: TextStyle(fontSize: 22)),
            //   ),
            //   Container(
            //     height: 20,
            //   ),

            Container(
              height: 30,
            ),

            CircleAvatar(
              radius: 60,
              backgroundImage: NetworkImage(widget.user.photoUrl.toString()),
            ),

            Container(
              height: 30,
            ),
            Container(
              margin: EdgeInsets.only(right: 30),
              child: Text(
                  'Patient Name  :  ' + widget.user.displayName.toString(),
                  style: TextStyle(fontSize: 22)),
            ),
            Container(
              height: 50,
            ),
            Container(
              margin: EdgeInsets.only(right: 30),
              child: Text(
                'Your appointment is scheduled on ',
                style: TextStyle(fontSize: 22),
              ),
            ),
            Container(
              height: 13,
            ),

            Container(
              child: ListTile(
                leading: Text(
                  'Day : ',
                  style: TextStyle(fontSize: 20),
                ),
                title: Text(
                  timestampToDate(dayOfAppointment).day.toString() +
                      "  " +
                      months[timestampToDate(dayOfAppointment).month - 1]
                          .toString() +
                      "  " +
                      timestampToDate(dayOfAppointment).year.toString(),
                  style: TextStyle(fontSize: 20),
                ),
              ),
            ),

            Container(
              child: ListTile(
                leading: Text(
                  'Time : ',
                  style: TextStyle(fontSize: 20),
                ),
                title: Text(
                  appointmentTime,
                  style: TextStyle(fontSize: 20),
                ),
              ),
            ),

            Container(
              child: ListTile(
                leading: Text(
                  'Existing Symptoms : ',
                  style: TextStyle(fontSize: 20),
                ),
                title: Text(
                  problem,
                  style: TextStyle(fontSize: 20),
                ),
              ),
            ),

            Container(
              child: Image.asset('asset/calendar.png'),
            ),
          ]),
        ),
      ),
      floatingActionButton: FloatingActionButton(onPressed: () {
        print(dayOfAppointment);
      }),
    );
  }

  DateTime timestampToDate(Timestamp t) {
    return DateTime.fromMicrosecondsSinceEpoch(t.microsecondsSinceEpoch);
  }
}
