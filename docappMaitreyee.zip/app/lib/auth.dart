import 'package:app/dashboard.dart';
import 'package:app/doctorview.dart';
import 'package:connectivity/connectivity.dart';
import 'package:delayed_display/delayed_display.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:google_sign_in/google_sign_in.dart';

GoogleSignIn _googleSignIn = GoogleSignIn(
  scopes: <String>[
    'email',
  ],
);

class Auth extends StatefulWidget {
  @override
  State createState() => AuthState();
}

class AuthState extends State<Auth> {
  GoogleSignInAccount? _currentUser;
  bool isWorking = true, isconnected = true;

  checkInternet() async {
    var connectivityResult = await (Connectivity().checkConnectivity());
    if (connectivityResult == ConnectivityResult.mobile) {
      print('mobile internet');
      setState(() {
        isconnected = true;
      });
    } else if (connectivityResult == ConnectivityResult.wifi) {
      print('wifi internet');
      setState(() {
        isconnected = true;
      });
    } else {
      print('no internet');
      setState(() {
        isconnected = false;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    _googleSignIn.onCurrentUserChanged.listen((GoogleSignInAccount? account) {
      setState(() {
        _currentUser = account;
      });

      setState(() {
        isWorking = false;
      });
    });
    checkInternet();
    _googleSignIn.signInSilently();
  }

  String? _pickFirstNamedContact(Map<String, dynamic> data) {
    final List<dynamic>? connections = data['connections'];
    final Map<String, dynamic>? contact = connections?.firstWhere(
      (dynamic contact) => contact['names'] != null,
      orElse: () => null,
    );
    if (contact != null) {
      final Map<String, dynamic>? name = contact['names'].firstWhere(
        (dynamic name) => name['displayName'] != null,
        orElse: () => null,
      );
      if (name != null) {
        return name['displayName'];
      }
    }
    return null;
  }

  Future<void> _handleSignIn() async {
    try {
      await _googleSignIn.signIn();
    } catch (error) {
      print(error);
    }
  }

  void signOut() {
    _handleSignOut();
  }

  Future<void> _handleSignOut() => _googleSignIn.disconnect();

  Widget _buildBody() {
    GoogleSignInAccount? user = _currentUser;
    if (user != null) {
      if (user.email != "maitreyi.kalantre@maharshikarvebcapune.org") {
        return Dashboard(user, signOut);
      } else {
        return DoctorView(user, signOut);
      }
    } else {
      return SafeArea(
          child: Stack(
        children: [
          Positioned(
            child: Column(
              children: <Widget>[
                Expanded(
                  child: Container(
                    color: Color.fromRGBO(188, 227, 243, 1),
                  ),
                ),
                Expanded(
                  child: Container(color: Color.fromRGBO(160, 214, 237, 1)),
                )
              ],
            ),
          ),
          Positioned(
              top: 80,
              left: 45,
              child: Text(
                'Welcome!',
                style: TextStyle(
                    color: Color.fromRGBO(0, 49, 89, 1),
                    fontSize: 28,
                    fontWeight: FontWeight.bold),
              )),
          Positioned(
              top: 115,
              left: 45,
              child: Text(
                'Please login for an Appointment',
                style: TextStyle(
                    color: Color.fromRGBO(0, 49, 89, 1),
                    fontSize: 18,
                    fontWeight: FontWeight.bold),
              )),
          Positioned(
              top: 150,
              child: Container(
                height: 400,
                child: Image.asset('asset/frontdoc.jpg'),
              )),
          Positioned(
              top: 570,
              child: Center(
                widthFactor: 2.2,
                child: DelayedDisplay(
                  delay: Duration(milliseconds: 100),
                  child: InkWell(
                    onTap: () {
                      setState(() {
                        isWorking = true;
                      });
                      _handleSignIn();
                    },
                    child: Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                      elevation: 10,
                      child: Container(
                        padding: EdgeInsets.all(10),
                        child: Row(
                          children: [
                            Container(
                              width: 30,
                              child: Image.asset('asset/google.webp'),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Text(
                              'Login from Google',
                              style: TextStyle(color: Colors.black54),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ))
        ],
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: ConstrainedBox(
      constraints: const BoxConstraints.expand(),
      child: isconnected
          ? _buildBody()
          : Container(
              color: Colors.black12,
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.signal_wifi_connected_no_internet_4,
                      size: 50,
                    ),
                    Text('please Connect Internet'),
                    ElevatedButton(
                        onPressed: () {
                          checkInternet();
                        },
                        child: Text('Connected '))
                  ],
                ),
              ),
            ),
    ));
  }
}
