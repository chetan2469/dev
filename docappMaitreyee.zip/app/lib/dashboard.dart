import 'package:app/bookuser.dart';
import 'package:app/doctorInfo.dart';
import 'package:app/registrationuser.dart';
import 'package:app/service/notificationService.dart';
import 'package:app/viewmyAppointment.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:provider/provider.dart';

class Dashboard extends StatefulWidget {
  Function signOut;
  GoogleSignInAccount user;

  Dashboard(this.user, this.signOut);

  @override
  _DashboardState createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  bool isUser = false;
  bool isWorking = true;
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  GlobalKey<ScaffoldState> _drawerKey = GlobalKey();

  void _read() async {
    DocumentSnapshot documentSnapshot;
    try {
      documentSnapshot = await firestore
          .collection('docusers')
          .doc(widget.user.email.toString())
          .get();
      print(documentSnapshot.data());
      if (documentSnapshot.data() != null) {
        setState(() {
          isUser = true;
        });
      }
      setState(() {
        isWorking = false;
      });
    } catch (e) {
      print(e);
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _read();
  }

  Widget _buildBody() {
    if (isUser == false) {
      return RegistrationUserPage(widget.user, widget.signOut);
    } else {
      return Container(
        child: Stack(
          children: [
            Positioned(
                child: Container(color: Color.fromRGBO(152, 209, 236, 1))),
            Positioned(
              bottom: -230,
              left: -40,
              right: -130,
              top: 50,
              child: Container(
                child: Image.asset('asset/maskdoc.png'),
              ),
            ),
            Positioned(
              left: MediaQuery.of(context).size.width - 90,
              top: 50,
              child: Container(
                margin: EdgeInsets.only(),
                child: CircleAvatar(
                  radius: 30,
                  backgroundImage:
                      NetworkImage(widget.user.photoUrl.toString()),
                ),
              ),
            ),
            Positioned(
              left: MediaQuery.of(context).size.width - 370,
              top: 130,
              child: Container(
                margin: EdgeInsets.only(),
                child: Text(
                  'A Doctor who is always with you!',
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Color.fromRGBO(0, 49, 89, 1),
                      fontSize: 20),
                ),
              ),
            ),
            Positioned(
              left: MediaQuery.of(context).size.width - 370,
              top: 170,
              child: Container(
                margin: EdgeInsets.only(),
                child: Text(
                  'Hello ' + widget.user.displayName.toString() + '!',
                  style: TextStyle(
                      //fontWeight: FontWeight.bold,
                      color: Color.fromRGBO(0, 49, 89, 1),
                      fontSize: 19),
                ),
              ),
            ),
            Positioned(
              top: 219,
              left: 36,
              child: Container(
                width: 180,
                height: 60,
                child: InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => BookUserpage(widget.user)),
                    );
                  },
                  child: Card(
                    elevation: 30,
                    shape: RoundedRectangleBorder(
                        side: BorderSide(color: Colors.white),
                        borderRadius: BorderRadius.circular(30)),
                    child: Center(
                      child: Text(
                        'Book Appoinment',
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                    color: Color.fromRGBO(0, 179, 154, 1),
                  ),
                ),
              ),
            ),
            Positioned(
              top: 283,
              left: 36,
              child: Container(
                width: 180,
                height: 60,
                child: InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => ViewmyAppointment(widget.user)),
                    );
                  },
                  child: Card(
                    elevation: 30,
                    shape: RoundedRectangleBorder(
                        side: BorderSide(color: Colors.white),
                        borderRadius: BorderRadius.circular(30)),
                    child: Center(
                      child: Text(
                        'View Appoinment',
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                    color: Color.fromRGBO(0, 49, 89, 1),
                  ),
                ),
              ),
            ),
            Positioned(
              left: MediaQuery.of(context).size.width - 450,
              top: 50,
              child: Container(
                  width: 180,
                  child: IconButton(
                      onPressed: () {
                        _drawerKey.currentState!.openDrawer();
                      },
                      icon: Icon(
                        Icons.menu,
                        size: 35,
                      ))),
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {},
      ),
      key: _drawerKey,
      backgroundColor: isWorking
          ? Color.fromRGBO(188, 227, 243, 1)
          : Color.fromRGBO(188, 227, 243, 1),
      drawer: Drawer(
        child: Column(
          children: [
            Container(
              height: 100,
            ),
            CircleAvatar(
              radius: 45,
              backgroundImage: NetworkImage(widget.user.photoUrl.toString()),
            ),
            Container(
              height: 20,
            ),
            Text(
              widget.user.displayName.toString(),
              style: TextStyle(fontSize: 18),
            ),
            Container(
              height: 20,
            ),
            Text(
              widget.user.email,
              style: TextStyle(fontSize: 18),
            ),
            Container(
              height: 30,
            ),
            Divider(),
            Container(
              margin: EdgeInsets.all(15),
              alignment: Alignment.centerLeft,
              child: Text(
                'Book Appoitnment',
                style: TextStyle(fontSize: 20),
                textAlign: TextAlign.left,
              ),
            ),
            Divider(),
            Container(
              margin: EdgeInsets.all(15),
              alignment: Alignment.centerLeft,
              child: Text(
                'View Appoitnment',
                style: TextStyle(fontSize: 20),
                textAlign: TextAlign.left,
              ),
            ),
            Divider(),
            InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => DoctorInfo()),
                );
              },
              child: Container(
                margin: EdgeInsets.all(15),
                alignment: Alignment.centerLeft,
                child: Text(
                  'Doctor Info',
                  style: TextStyle(fontSize: 20),
                  textAlign: TextAlign.left,
                ),
              ),
            ),
            Divider(),
            InkWell(
              onTap: () {
                setState(() {
                  isWorking = true;
                });
                Navigator.pop(context);
                widget.signOut();
                widget.user.clearAuthCache();
              },
              child: Container(
                margin: EdgeInsets.all(15),
                alignment: Alignment.centerLeft,
                child: Text(
                  'Log out',
                  style: TextStyle(fontSize: 20),
                  textAlign: TextAlign.left,
                ),
              ),
            ),
            Divider(),
          ],
        ),
      ),
      body: Center(
        child: isWorking ? CircularProgressIndicator() : _buildBody(),
      ),
    );
  }
}
