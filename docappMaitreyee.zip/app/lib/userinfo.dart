import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:google_sign_in/google_sign_in.dart';

class UserInfo extends StatefulWidget {
  String userMail;

  UserInfo(this.userMail);

  @override
  _UserInfoState createState() => _UserInfoState();
}

class _UserInfoState extends State<UserInfo> {
  String address = ' ';
  String name = ' ';
  String mobile = ' ';
  String gender = ' ';
  Timestamp dob = Timestamp.fromMillisecondsSinceEpoch(34567890);

  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  void readUserData() async {
    DocumentSnapshot documentSnapshot;
    try {
      documentSnapshot = await firestore
          .collection('docusers')
          .doc(widget.userMail.toString())
          .get();

      setState(() {
        name = (documentSnapshot.data() as dynamic)['name'];
        address = (documentSnapshot.data() as dynamic)['address'];
        mobile = (documentSnapshot.data() as dynamic)['mobile'];
        gender = (documentSnapshot.data() as dynamic)['gender'];
        dob = (documentSnapshot.data() as dynamic)['dob'];
      });
    } catch (e) {
      print(e);
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    print(widget.userMail);
    readUserData();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Scaffold(
          body: SafeArea(
              child: Column(
        children: [
          Row(
            children: [
              Container(
                margin: EdgeInsets.only(top: 5, left: 0),
                alignment: Alignment.topLeft,
                height: 40,
                child: IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: Icon(Icons.arrow_back, size: 35)),
              ),
              Container(
                margin: EdgeInsets.only(top: 15, left: 75),
                child: Text(
                  'Patient Information',
                  style: TextStyle(
                    fontSize: 20,
                    //fontWeight: FontWeight.bold
                  ),
                ),
              ),
            ],
          ),
          Container(
            margin: EdgeInsets.only(),
            child: CircleAvatar(
              radius: 90,
              backgroundImage: NetworkImage(
                  'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRIpyao3Dbz2P7W_b7q2EqycRQRkcyOmaFFLQ&usqp=CAU'),
            ),
          ),
          Container(
            child: ListTile(
              leading: Text(
                'Name : ',
                style: TextStyle(fontSize: 15),
              ),
              title: Text(
                name,
                style: TextStyle(fontSize: 15),
              ),
            ),
          ),
          Container(
            child: ListTile(
              leading: Text(
                'Gender : ',
                style: TextStyle(fontSize: 15),
              ),
              title: Text(
                gender,
                style: TextStyle(fontSize: 15),
              ),
            ),
          ),
          Container(
            child: ListTile(
              leading: Text(
                'Address : ',
                style: TextStyle(fontSize: 15),
              ),
              title: Text(
                address,
                style: TextStyle(fontSize: 15),
              ),
            ),
          ),
          Container(
            child: ListTile(
              leading: Text(
                'Contact number : ',
                style: TextStyle(fontSize: 15),
              ),
              title: Text(
                mobile,
                style: TextStyle(fontSize: 15),
              ),
            ),
          ),
        ],
      ))),
    );
  }
}
