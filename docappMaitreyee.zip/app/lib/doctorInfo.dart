import 'package:flutter/material.dart';

class DoctorInfo extends StatefulWidget {
  const DoctorInfo({Key? key}) : super(key: key);

  @override
  _DoctorInfoState createState() => _DoctorInfoState();
}

class _DoctorInfoState extends State<DoctorInfo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(188, 227, 243, 1),
      body: SafeArea(
        child: Center(
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.all(20),
                alignment: Alignment.topLeft,
                height: 20,
                child: IconButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: Icon(Icons.arrow_back)),
              ),
              Container(
                  height: MediaQuery.of(context).size.height * .4,
                  child: Image.asset('asset/doc.png')),
              Container(
                height: 40,
              ),
              Container(
                  margin: EdgeInsets.only(left: 25),
                  alignment: Alignment.bottomLeft,
                  child: Text(
                    'Dr Mary Gomez ',
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.cyan),
                  )),
              Container(
                  margin: EdgeInsets.only(left: 25),
                  alignment: Alignment.bottomLeft,
                  child: Text(
                    'Speacialisation',
                    style: TextStyle(fontSize: 16, color: Colors.cyan),
                  )),
              Container(
                  margin: EdgeInsets.only(left: 25, top: 15, bottom: 15),
                  alignment: Alignment.bottomLeft,
                  child: Text(
                    'it is a long established fact that a reader will be distracted by the readable content of a page when looking ',
                    style: TextStyle(fontSize: 14, color: Colors.cyan),
                  )),
              Container(
                  margin: EdgeInsets.only(left: 20, right: 20),
                  child: Divider(color: Colors.cyan)),
              Container(
                  margin: EdgeInsets.only(left: 25, top: 10, bottom: 10),
                  alignment: Alignment.bottomLeft,
                  child: Text(
                    'Description',
                    style: TextStyle(
                        fontSize: 18,
                        color: Colors.cyan,
                        fontWeight: FontWeight.bold),
                  )),
              Container(
                  margin: EdgeInsets.only(left: 25, bottom: 15),
                  alignment: Alignment.bottomLeft,
                  child: Text(
                    'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using Content here, content here, making it look like readable English.',
                    style: TextStyle(fontSize: 14, color: Colors.cyan),
                  )),
            ],
          ),
        ),
      ),
    );
  }
}
